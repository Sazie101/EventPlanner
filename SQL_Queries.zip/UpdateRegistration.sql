CREATE OR ALTER PROCEDURE usp_UpdateRegistrations
    @RegistrationId INT,
    @AttendeeName NVARCHAR(50), 
    @RegistrationDate DATETIME
AS 
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION
            UPDATE Registrations
            SET 
                AttendeeName = @AttendeeName, 
                RegistrationDate = @RegistrationDate
            WHERE 
                RegistrationId = @RegistrationId;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF(@@TRANCOUNT > 0) 
            ROLLBACK TRANSACTION;
    END CATCH;
END;
