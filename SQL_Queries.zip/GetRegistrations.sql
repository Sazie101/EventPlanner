CREATE OR ALTER PROCEDURE usp_GetRegistrations
@EventId INT
AS 
BEGIN
	SELECT * 
	FROM Registrations
	WHERE EventId = @EventId
END