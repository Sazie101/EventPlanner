CREATE OR ALTER PROCEDURE usp_InsertRegistration
    @AttendeeName NVARCHAR(50), 
    @RegistrationDate DATETIME, 
    @EventId INT
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION
            INSERT INTO Registrations (AttendeeName, RegistrationDate, EventId)
            VALUES (@AttendeeName, @RegistrationDate, @EventId)
        COMMIT TRANSACTION
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 
            ROLLBACK TRANSACTION
    END CATCH
END
