-- -- Create Events Table
CREATE TABLE Events (
    EventId INT PRIMARY KEY IDENTITY(1, 1),
    EventName VARCHAR(50),
    EventDescription VARCHAR(MAX),
    EventDate DATETIME,
    EventLocation VARCHAR(MAX),
    EventCapacity INT
);

-- -- Create Registrations Table
CREATE TABLE Registrations (
    RegistrationId INT PRIMARY KEY IDENTITY(1, 1),
    AttendeeName VARCHAR(50),
    RegistrationDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    EventId INT FOREIGN KEY REFERENCES Events(EventId)
);
