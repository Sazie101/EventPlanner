CREATE OR ALTER PROCEDURE usp_GetRegistration
@EventId INT,
@RegistrationId INT
AS 
BEGIN
	SELECT * 
	FROM Registrations
	WHERE EventId = @EventId AND RegistrationId = @RegistrationId
END